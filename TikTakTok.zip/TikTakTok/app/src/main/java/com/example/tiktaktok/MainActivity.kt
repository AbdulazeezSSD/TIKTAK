package com.example.tiktaktok

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnStart.setOnClickListener{
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }
        var btn = findViewById<Button>(R.id.btnQuit)
        btnQuit.setOnClickListener{
            val builder = AlertDialog.Builder(this )
            builder.setTitle("QUIT ?")
            builder.setMessage("ARE YOU SURE YOU WANT TO QUIT ?")
            builder.setPositiveButton("Yes", { dialogInterface: DialogInterface, i : Int ->
                finish()
            })
            builder.setNegativeButton("No", {dialogInterface: DialogInterface, i : Int ->})
            builder.show()
        }
    }
}